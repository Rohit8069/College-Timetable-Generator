from flask import Flask
from flask import render_template, request, redirect
from itertools import permutations
import os
import csv
import random

app = Flask(__name__)


class TimeTable(dict):
    def __init__(self,name,slot_filled=False):
        self.name = name
        self.filled = {}
        self.slot_filled = slot_filled
        self.days = ['monday', 'tuesday', 'wednesday', 'thursday',  'friday']
        self.create_tt()

    def create_tt(self):
        for i in self.days:
            self[i] = {1: '', 2: '', 3: '', 4: '', 5: 'LUNCH', 6: '', 7: '', 8: ''}
            self.filled[i] = {1: self.slot_filled, 2: self.slot_filled, 3: self.slot_filled, 4: self.slot_filled, 5: True, 6: self.slot_filled, 7: self.slot_filled, 8: self.slot_filled}

def digit(l):
    for i in range(len(l)):
        if l[i].isdigit():
            l[i]=int(l[i])
    return l

all_classrooms = {}
all_faculty = {}
data=[]
temp=[]
teachers = []
class_timetables = {'3a':'','3b':'','5a':'','5b':'','7a':'','7b':''}

with open("dataset.csv",'r') as csvfile:
    reader=csv.reader(csvfile)
    next(reader)
    for lines in reader:
        digit(lines)
        data.append(tuple(lines))
        teachers.append(lines[3]) if lines[3] not in teachers else None
        all_faculty[lines[3]] = TimeTable(lines[3])
    for i in range(len(data)): #3A
        if (data[i][1])=='3a':
            temp.append(data[i])
        all_classrooms['3a']=tuple(temp)
    temp=[]
    for i in range(len(data)): #3B
        if data[i][1]=='3b':
            temp.append(data[i])
        all_classrooms['3b']=tuple(temp)
    temp=[]
    for i in range(len(data)): #5A
        if data[i][1]=='5a':
            temp.append(data[i])
        all_classrooms['5a']=tuple(temp)
    temp=[]
    for i in range(len(data)): #5B
        if data[i][1]=='5b':
            temp.append(data[i])
        all_classrooms['5b']=tuple(temp)
    temp=[]
    for i in range(len(data)): #7A
        if data[i][1]=='7a':
            temp.append(data[i])
        all_classrooms['7a']=tuple(temp)
    temp=[]
    for i in range(len(data)): #7B
        if data[i][1]=='7b':
            temp.append(data[i])
        all_classrooms['7b']=tuple(temp)

def generate_mine(class_name,tt,subjects):
    global all_faculty

    subjects = list(subjects)
    remaining_subjects = []
    filled_labs = ['tuesday','thursday']
    
    #generating labs
    for i in subjects:
        hours_left = i[4]
        flag = False
        temp = [i[1],i[0],i[2],i[3],"Lab"] if i[-1] == 1 else [i[1],i[0],i[2],i[3],"Theory"]
        if i[-1] == 1:
            course_table.append(temp) if temp not in course_table else None
            while hours_left > 0:
                day = random.choice(filled_labs)
                time = random.choice([1, 2, 6])
                if (time, day) in combs and (not all_faculty[i[3]].filled[day][time]):
                    if not ((time+1,day) in combs and (time+2,day) in combs):
                        continue
                    for j in range(time,time+3):
                        tt[day][j] = (i[0],i[3])
                        tt.filled[day][j] = True
                        all_faculty[i[3]][day][j] = (i[1][0]+str(i[1][1]).upper(),i[2])
                        all_faculty[i[3]].filled[day][j] = True
                        combs.remove((j,day))
                        flag = True
                    if flag == True:
                        hours_left-=3
                        filled_labs.remove(day)
        else:
            course_table.append(temp) if temp not in course_table else None
            remaining_subjects.append(i)
    
    #generating first hour classes
    for i in remaining_subjects:
        if i[-3] == 1:
            hours_left = 1
            flag = False
            tries = 0
            times = [1]
            while hours_left > 0:
                day = random.choice(['monday', 'tuesday', 'wednesday', 'thursday', 'friday'])
                time = random.choice(times)
                tries += 1
                if (time, day) in combs and (not all_faculty[i[3]].filled[day][time]):
                    tt[day][time] = (i[0],i[3])
                    tt.filled[day][time] = True
                    all_faculty[i[3]][day][time] = all_faculty[i[3]][day][time] = (i[1][0]+str(i[1][1]).upper(),i[2])
                    all_faculty[i[3]].filled[day][time] = True
                    flag = True
                    if flag == True:
                        hours_left -= 1
                        combs.remove((time,day))
                        temp = list(remaining_subjects[remaining_subjects.index(i)])
                        temp[4] -= 1
                        remaining_subjects[remaining_subjects.index(i)] = tuple(temp)
                if tries > 20:
                    times = [1,2]
    
    #generating all classes
    for i in remaining_subjects:
        hours_left = i[4]
        flag = False
        temp_comb = combs
        while hours_left > 0:
            day = random.choice(['monday', 'tuesday', 'wednesday', 'thursday', 'friday'])
            time = random.choice([1, 2, 3, 4, 6, 7, 8])
            hours_today = 0
            if i[2] in list(tt[day].values()):
                hours_today = list(tt[day].values()).count(i[2])
            if hours_today < 2:
                if (time, day) in temp_comb and (not all_faculty[i[3]].filled[day][time]):
                    if time == 0:
                        if (all_faculty[i[3]].filled[day][time+1] and all_faculty[i[3]].filled[day][time+2]):
                            continue
                    if time == 1:
                        if (all_faculty[i[3]].filled[day][time+1] and all_faculty[i[3]].filled[day][time+2]):
                            continue
                    elif time < 7 and time > 1:
                        if (all_faculty[i[3]].filled[day][time-1] and all_faculty[i[3]].filled[day][time+1]) or (all_faculty[i[3]].filled[day][time+1] and all_faculty[i[3]].filled[day][time+2]):
                            continue
                    elif time == 7:
                        if (all_faculty[i[3]].filled[day][time-1] and all_faculty[i[3]].filled[day][time+1]):
                            continue
                    elif time == 8:
                        if all_faculty[i[3]].filled[day][time-1] and all_faculty[i[3]].filled[day][time-2]:
                            continue
                    if time<8 and time > 1:
                        if tt[day][time+1] == i[2]:
                            continue
                        elif tt[day][time-1] == i[2]:
                            continue
                    if time == 8:
                        if tt[day][time-1] == i[2]:
                            continue
                    tt[day][time] = (i[0],i[3])
                    tt.filled[day][time] = True
                    all_faculty[i[3]][day][time] = all_faculty[i[3]][day][time] = (i[1][0]+str(i[1][1]).upper(),i[2])
                    all_faculty[i[3]].filled[day][time] = True
                    flag = True
                    if flag == True:
                        hours_left -= 1
                        temp_comb.remove((time,day))
        
    #generating extra curricular hours
    useless_hours = ['Mentor','Library','Sports']
    
    if len(combs) > 3:
        iterations = 3
    elif len(combs) == 2:
        iterations = 2
    else:
        iterations = 1
    while iterations > 0:
        temp = random.choice(combs)
        class_choice = random.choice(useless_hours)
        tt[temp[1]][temp[0]] = ('',class_choice)
        tt.filled[temp[1]][temp[0]] = True
        combs.remove(temp)
        iterations -= 1
    return tt

combs = []
course_table = []

for i in class_timetables:
    days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
    times = [1, 2, 3, 4, 6, 7, 8]
    permut = permutations(times, len(days))
    combs = []
    for comb in permut:
        zipped = zip(comb, days)
        combs.extend(list(zipped))
    combs = list(set(combs))
    class_timetables[i] = generate_mine(i,TimeTable(i),all_classrooms[i])

days = ["Day","8:00-8:50","8:50-9:40","9:50-10:40","10:40-11:30","11:30-12:20","1:00-1:50","1:50-2:40","2:40-3:30"]
sems = ['3rd Sem','5th Sem','7th Sem']
sections = ['A','B']


#######################FLASK###################################

@app.route('/faculty', methods = ['GET',"POST"])
def faculty():
    if request.form.get('submit_button') == 'show_tt':
        s = []
        working_days = all_faculty[request.form.get('comp_selected')]
        for timetable in working_days:
            temp = [timetable.capitalize()]
            for j in working_days[timetable]:
                temp.append(working_days[timetable][j])
            s.append(temp)
        return render_template("ftt.html", teachers = teachers, days = days, working_days = s, isSelected = True, select = request.form.get('comp_selected'))

    return render_template("ftt.html", teachers = teachers, isSelected = False, select = '')

@app.route('/classroom', methods = ["GET","POST"])
def classroom():
    if request.form.get('submit_button') == 'show_tt':
        s = []
        working_days = class_timetables[str(str(request.form.get("sem"))[0]+""+str(request.form.get("section"))).lower()]
        for timetable in working_days:
            temp = [timetable.capitalize()]
            for j in working_days[timetable]:
                temp.append(working_days[timetable][j])
            s.append(temp)
        return render_template("ctt.html", course_table = course_table, days = days, working_days = s, isSelected = True, sems = sems, sections = sections, select_sem = str(request.form.get("sem")), select_section = str(request.form.get("section")))

    return render_template("ctt.html", isSelected = False, sections = sections, sems = sems, select_sem = '', select_section = '')

@app.route('/', methods=['POST', 'GET'])
def main_page():
    if request.form.get('submit_button') == 'Class timetable':
        return redirect('classroom')
    elif request.form.get('submit_button') == 'Faculty timetable':
        return redirect('faculty')
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)